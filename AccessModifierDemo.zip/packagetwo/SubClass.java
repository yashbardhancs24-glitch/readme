package packagetwo;
import packageone.SuperClass;
public class SubClass extends SuperClass {
    public void accessTest() {
        publicMethod();
        protectedMethod();
        System.out.println("Default and private methods are not accessible here.");
    }
    public static void main(String[] args) {
        SubClass obj = new SubClass();
        obj.accessTest();
    }
}
