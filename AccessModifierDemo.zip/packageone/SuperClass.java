package packageone;
public class SuperClass {
    public void publicMethod() {
        System.out.println("Public method accessible everywhere.");
    }
    protected void protectedMethod() {
        System.out.println("Protected method accessible in subclass or same package.");
    }
    void defaultMethod() {
        System.out.println("Default method accessible only within same package.");
    }
    private void privateMethod() {
        System.out.println("Private method accessible only within this class.");
    }
}
