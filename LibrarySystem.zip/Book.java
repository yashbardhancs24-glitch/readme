public class Book {
    String title;
    String author;
    boolean issued;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.issued = false;
    }

    public void displayBook() {
        System.out.println("Title: " + title + ", Author: " + author + ", Issued: " + issued);
    }
}
