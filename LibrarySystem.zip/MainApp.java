public class MainApp {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook("Java Programming", "James Gosling");
        library.registerMember("Yash Bardhan", 101);
        library.issueBook();
    }
}
