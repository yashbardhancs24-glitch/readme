public class Library {
    Book book;
    Member member;

    public void addBook(String title, String author) {
        book = new Book(title, author);
        System.out.println("Book added successfully.");
        book.displayBook();
    }

    public void registerMember(String name, int id) {
        member = new Member(name, id);
        System.out.println("Member registered successfully.");
        member.displayMember();
    }

    public void issueBook() {
        if (book != null && member != null && !book.issued) {
            book.issued = true;
            System.out.println("Book issued to " + member.name);
        } else {
            System.out.println("Cannot issue book.");
        }
    }
}
