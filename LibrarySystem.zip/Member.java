public class Member {
    String name;
    int id;

    public Member(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public void displayMember() {
        System.out.println("Member Name: " + name + ", ID: " + id);
    }
}
