package company.payroll;
public class BonusCalculator {
    public double calculateBonus(double salary) {
        return salary * 0.10;
    }
}
