import company.staff.Employee;
import company.payroll.*;
public class MainApp {
    public static void main(String[] args) {
        Employee emp = new Employee("Yash Bardhan", 1001, 50000);
        BonusCalculator bc = new BonusCalculator();
        double bonus = bc.calculateBonus(emp.getSalary());
        double totalSalary = emp.getSalary() + bonus;

        System.out.println("Employee Name: " + emp.getName());
        System.out.println("Employee ID: " + emp.getId());
        System.out.println("Base Salary: " + emp.getSalary());
        System.out.println("Bonus: " + bonus);
        System.out.println("Total Salary after Bonus: " + totalSalary);
    }
}
