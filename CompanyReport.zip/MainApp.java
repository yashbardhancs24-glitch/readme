import company.sales.SalesReport;
import company.hr.EmployeeReport;
public class MainApp {
    public static void main(String[] args) {
        SalesReport sales = new SalesReport();
        EmployeeReport hr = new EmployeeReport();
        System.out.println("Company Combined Report:\n");
        sales.displaySales();
        System.out.println();
        hr.displayEmployeePerformance();
    }
}
