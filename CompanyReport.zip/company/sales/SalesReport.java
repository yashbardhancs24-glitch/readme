package company.sales;
public class SalesReport {
    public void displaySales() {
        System.out.println("Region-wise Sales Report:");
        System.out.println("North: $50,000");
        System.out.println("South: $40,000");
        System.out.println("East: $60,000");
        System.out.println("West: $45,000");
    }
}
