package company.hr;
public class EmployeeReport {
    public void displayEmployeePerformance() {
        System.out.println("Employee Performance Report:");
        System.out.println("Alice - Excellent");
        System.out.println("Bob - Good");
        System.out.println("Charlie - Average");
    }
}
