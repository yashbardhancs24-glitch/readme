import static java.lang.Math.*;
public class InterestCalculator {
    public static double simpleInterest(double p, double r, double t) {
        return (p * r * t) / 100;
    }
    public static double compoundInterest(double p, double r, double t) {
        return p * pow((1 + r / 100), t) - p;
    }
    public static void main(String[] args) {
        double p = 10000, r = 5, t = 2;
        System.out.println("Simple Interest: " + simpleInterest(p, r, t));
        System.out.println("Compound Interest: " + compoundInterest(p, r, t));
    }
}
