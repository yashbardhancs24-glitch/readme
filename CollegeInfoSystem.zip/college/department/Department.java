package college.department;
public class Department {
    private String deptName;
    private int totalFaculty;

    public Department(String deptName, int totalFaculty) {
        this.deptName = deptName;
        this.totalFaculty = totalFaculty;
    }

    public String getDetails() {
        return "Department: " + deptName + ", Total Faculty: " + totalFaculty;
    }
}
