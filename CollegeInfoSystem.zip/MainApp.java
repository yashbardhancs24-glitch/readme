import college.student.Student;
import college.faculty.Faculty;
import college.department.*;
import static java.lang.System.out;

public class MainApp {
    public static void main(String[] args) {
        Student s = new Student("Yash Bardhan", 101, "Computer Science");
        Faculty f = new Faculty("Dr. Sharma", "Java Programming");
        Department d = new Department("Computer Science", 10);

        out.println("College Information:\n");
        out.println(s.getDetails());
        out.println(f.getDetails());
        out.println(d.getDetails());
    }
}
