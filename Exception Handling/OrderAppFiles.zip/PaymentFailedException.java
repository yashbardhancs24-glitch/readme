public class PaymentFailedException extends Exception {
    public PaymentFailedException(String a) {
        super(a);
    }
}
