public class OutOfStockException extends Exception {
    public OutOfStockException(String a) {
        super(a);
    }
}
