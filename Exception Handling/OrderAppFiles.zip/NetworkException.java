public class NetworkException extends Exception {
    public NetworkException(String a) {
        super(a);
    }
}
