import java.util.*;

public class OrderApp {
    public static void placeOrder() throws PaymentFailedException, OutOfStockException, NetworkException {
        Random r = new Random();
        int n = r.nextInt(3);
        if(n == 0) throw new PaymentFailedException("pay fail");
        else if(n == 1) throw new OutOfStockException("no stock");
        else if(n == 2) throw new NetworkException("net bad");
        else System.out.println("ok order");
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean done = false;
        while(!done) {
            System.out.println("try order...");
            try {
                placeOrder();
                System.out.println("done");
                done = true;
            } catch (PaymentFailedException e) {
                System.out.println("pay prob");
            } catch (OutOfStockException e) {
                System.out.println("stock prob");
            } catch (NetworkException e) {
                System.out.println("net prob");
            }
        }
        s.close();
    }
}
