import java.util.*;

public class TemperatureConvert {
    public static void main(String[] args) {
        Scanner abc = new Scanner(System.in);
        try {
            System.out.print("Enter value: ");
            double xyz = abc.nextDouble();
            System.out.print("Enter unit (C or F): ");
            String pqr = abc.next();
            if (pqr.equalsIgnoreCase("C")) {
                if (xyz < -273.15) {
                    throw new Exception("Error: Temperature below absolute zero is not possible!");
                }
                double def = (xyz * 9 / 5) + 32;
                System.out.println("In Fahrenheit: " + def);
            } else if (pqr.equalsIgnoreCase("F")) {
                if (xyz < -459.67) {
                    throw new Exception("Error: Temperature below absolute zero is not possible!");
                }
                double ghi = (xyz - 32) * 5 / 9;
                System.out.println("In Celsius: " + ghi);
            } else {
                System.out.println("Invalid unit!");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
