import java.util.*;

class InvalidSeatException extends Exception {
    public InvalidSeatException(String msg) {
        super(msg);
    }
}

class SeatAlreadyBookedException extends Exception {
    public SeatAlreadyBookedException(String msg) {
        super(msg);
    }
}

public class SeatBooking {
    static Map<Integer, Boolean> abc = new HashMap<>();

    static {
        for (int xyz = 1; xyz <= 5; xyz++) {
            abc.put(xyz, false);
        }
    }

    public static void bookSeat(int pqr) throws InvalidSeatException, SeatAlreadyBookedException {
        if (!abc.containsKey(pqr)) {
            throw new InvalidSeatException("Invalid seat number");
        }
        if (abc.get(pqr)) {
            throw new SeatAlreadyBookedException("Seat already booked");
        }
        abc.put(pqr, true);
        System.out.println("Seat booked: " + pqr);
    }

    public static void main(String[] args) {
        try {
            bookSeat(2);
            bookSeat(2);
        } catch (InvalidSeatException e) {
            System.out.println(e.getMessage());
        } catch (SeatAlreadyBookedException e) {
            System.out.println(e.getMessage());
        }
    }
}
