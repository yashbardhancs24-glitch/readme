public class InvalidReturnException extends Exception {
    public InvalidReturnException(String msg) {
        super(msg);
    }
}
