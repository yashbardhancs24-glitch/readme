import java.util.*;

public class LibrarySystem {
    static Map<String, Boolean> abc = new HashMap<>();
    static Map<String, List<String>> xyz = new HashMap<>();

    public static void borrowBook(String a, String b) throws BookNotAvailableException, UserLimitExceededException {
        if (!abc.containsKey(b) || !abc.get(b)) {
            throw new BookNotAvailableException("Book not available");
        }
        if (!xyz.containsKey(a)) {
            xyz.put(a, new ArrayList<>());
        }
        if (xyz.get(a).size() >= 5) {
            throw new UserLimitExceededException("User limit exceeded");
        }
        xyz.get(a).add(b);
        abc.put(b, false);
        System.out.println(a + " borrowed " + b);
    }

    public static void returnBook(String a, String b) throws InvalidReturnException {
        if (!xyz.containsKey(a) || !xyz.get(a).contains(b)) {
            throw new InvalidReturnException("Invalid return");
        }
        xyz.get(a).remove(b);
        abc.put(b, true);
        System.out.println(a + " returned " + b);
    }

    public static void main(String[] args) {
        abc.put("Book1", true);
        abc.put("Book2", true);
        abc.put("Book3", true);

        try {
            borrowBook("User1", "Book1");
            borrowBook("User1", "Book2");
            returnBook("User1", "Book3");
        } catch (BookNotAvailableException e) {
            System.out.println("Log: " + e.getMessage());
        } catch (UserLimitExceededException e) {
            System.out.println("Log: " + e.getMessage());
        } catch (InvalidReturnException e) {
            System.out.println("Log: " + e.getMessage());
        }
    }
}
