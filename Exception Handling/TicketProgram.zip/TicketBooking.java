
public class TicketBooking {
    public static void checkSeatAvailability(boolean abc) throws SeatUnavailableException {
        if (!abc) {
            throw new SeatUnavailableException("No seats available");
        }
    }

    public static void processPayment(boolean xyz) throws PaymentFailedException {
        if (!xyz) {
            throw new PaymentFailedException("Payment failed");
        }
    }

    public static void bookTicket(boolean abc, boolean xyz) throws Exception {
        checkSeatAvailability(abc);
        processPayment(xyz);
        System.out.println("Ticket booked successfully");
    }

    public static void main(String[] args) {
        try {
            bookTicket(false, true);
        } catch (SeatUnavailableException e) {
            System.out.println("Seat issue: " + e.getMessage());
        } catch (PaymentFailedException e) {
            System.out.println("Payment issue: " + e.getMessage());
        }
    }
}
