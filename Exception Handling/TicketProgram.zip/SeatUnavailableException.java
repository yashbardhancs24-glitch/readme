
public class SeatUnavailableException extends Exception {
    public SeatUnavailableException(String abc) {
        super(abc);
    }
}
