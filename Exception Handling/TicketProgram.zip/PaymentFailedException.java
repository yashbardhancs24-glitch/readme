
public class PaymentFailedException extends Exception {
    public PaymentFailedException(String abc) {
        super(abc);
    }
}
