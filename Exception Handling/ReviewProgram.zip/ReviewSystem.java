
import java.util.Scanner;

public class ReviewSystem {
    public static void submitReview(int abc, String xyz) throws InvalidRatingException, EmptyReviewException {
        if (abc < 1 || abc > 5) {
            throw new InvalidRatingException("Rating must be between 1 and 5");
        }
        if (xyz == null || xyz.trim().isEmpty()) {
            throw new EmptyReviewException("Comment cannot be empty");
        }
        System.out.println("Review submitted: Rating " + abc + ", Comment: " + xyz);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter rating (1-5): ");
        int abc = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter comment: ");
        String xyz = sc.nextLine();
        try {
            submitReview(abc, xyz);
        } catch (InvalidRatingException e) {
            System.out.println("Invalid rating: " + e.getMessage());
        } catch (EmptyReviewException e) {
            System.out.println("Empty comment: " + e.getMessage());
        }
    }
}
