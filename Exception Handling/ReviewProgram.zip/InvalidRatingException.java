
public class InvalidRatingException extends Exception {
    public InvalidRatingException(String xyz) {
        super(xyz);
    }
}
