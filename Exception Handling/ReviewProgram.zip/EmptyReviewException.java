
public class EmptyReviewException extends Exception {
    public EmptyReviewException(String xyz) {
        super(xyz);
    }
}
