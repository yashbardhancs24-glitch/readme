
import java.io.*;

public class ExamSystem {
    public static void validateStudent(boolean abc) throws InvalidStudentException {
        if (!abc) {
            throw new InvalidStudentException("Student is not valid");
        }
    }

    public static void submitExam(boolean abc) throws InvalidStudentException, IOException {
        validateStudent(abc);
        throw new IOException("Error while submitting exam");
    }

    public static void main(String[] xyz) {
        try {
            submitExam(false);
        } catch (InvalidStudentException e) {
            System.out.println("Invalid student: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO issue: " + e.getMessage());
        } finally {
            System.out.println("Exam submission process completed.");
        }
    }
}
