
public class InvalidStudentException extends Exception {
    public InvalidStudentException(String abc) {
        super(abc);
    }
}
