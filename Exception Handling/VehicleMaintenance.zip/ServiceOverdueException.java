public class ServiceOverdueException extends Exception {
    public ServiceOverdueException(String msg) {
        super(msg);
    }
}
