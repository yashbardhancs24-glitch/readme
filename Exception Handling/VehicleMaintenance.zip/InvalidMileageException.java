public class InvalidMileageException extends Exception {
    public InvalidMileageException(String msg) {
        super(msg);
    }
}
