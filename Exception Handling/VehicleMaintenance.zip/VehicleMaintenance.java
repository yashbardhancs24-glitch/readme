import java.time.LocalDate;

public class VehicleMaintenance {
    public static void checkMaintenance(LocalDate abc, int xyz) throws ServiceOverdueException, InvalidMileageException {
        if (xyz < 0) {
            throw new InvalidMileageException("Invalid mileage");
        }
        if (abc.isBefore(LocalDate.now())) {
            throw new ServiceOverdueException("Service overdue");
        }
    }

    public static void main(String[] args) {
        LocalDate abc = LocalDate.of(2023, 1, 1);
        int xyz = -100;
        try {
            checkMaintenance(abc, xyz);
        } catch (ServiceOverdueException e) {
            System.out.println("Owner notified: " + e.getMessage());
        } catch (InvalidMileageException e) {
            System.out.println("Owner notified: " + e.getMessage());
        }
    }
}
