import java.util.Scanner;

public class ValidateApp {
    public static void validate(String user, String pass) throws InvalidCredentialsException {
        String u = "abc";
        String p = "xyz";
        if(!user.equals(u) || !pass.equals(p)) {
            throw new InvalidCredentialsException("wrong info");
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean ok = false;
        while(!ok) {
            System.out.print("user: ");
            String u = s.nextLine();
            System.out.print("pass: ");
            String p = s.nextLine();
            try {
                validate(u, p);
                System.out.println("login done");
                ok = true;
            } catch (InvalidCredentialsException e) {
                System.out.println("try again");
            }
        }
        s.close();
    }
}
