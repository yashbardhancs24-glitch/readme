class GradeCheck {
    public static void main(String args[]) {
        String abc = "A+";
        try {
            int xyz = Integer.parseInt(abc);
            System.out.println("Grade is " + xyz);
        } catch (NumberFormatException e) {
            System.out.println("Invalid grade input: " + abc);
        }
    }
}
