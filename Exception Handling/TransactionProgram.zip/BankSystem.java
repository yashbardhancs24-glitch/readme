
public class BankSystem {
    public static void verifyAccount(boolean abc) throws AccountNotFoundException {
        if (!abc) {
            throw new AccountNotFoundException("Account not found");
        }
    }

    public static void processTransaction(boolean xyz) throws InsufficientFundsException {
        if (!xyz) {
            throw new InsufficientFundsException("Insufficient funds");
        }
    }

    public static void executeTransaction(boolean abc, boolean xyz) throws Exception {
        verifyAccount(abc);
        processTransaction(xyz);
        System.out.println("Transaction successful");
    }

    public static void main(String[] args) {
        try {
            executeTransaction(false, true);
        } catch (AccountNotFoundException e) {
            System.out.println("Account issue: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("Funds issue: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Other issue: " + e.getMessage());
        } finally {
            System.out.println("Transaction complete.");
        }
    }
}
