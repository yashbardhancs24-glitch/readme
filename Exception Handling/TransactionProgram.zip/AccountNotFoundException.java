
public class AccountNotFoundException extends Exception {
    public AccountNotFoundException(String abc) {
        super(abc);
    }
}
