class ATM {
    int balance = 10000;

    void withdraw(int xyz) throws InsufficientFundsException {
        if (xyz > balance) {
            throw new InsufficientFundsException("Not enough money in account");
        } else {
            balance = balance - xyz;
            System.out.println("Take your money. New balance: " + balance);
        }
    }

    public static void main(String args[]) {
        ATM abc = new ATM();
        try {
            abc.withdraw(15000);
        } catch (InsufficientFundsException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

class InsufficientFundsException extends Exception {
    InsufficientFundsException(String msg) {
        super(msg);
    }
}
