public class NetworkFailureException extends Exception {
    public NetworkFailureException(String a) {
        super(a);
    }
}
