public class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String a) {
        super(a);
    }
}
