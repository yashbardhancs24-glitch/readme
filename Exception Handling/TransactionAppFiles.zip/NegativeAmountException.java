public class NegativeAmountException extends Exception {
    public NegativeAmountException(String a) {
        super(a);
    }
}
