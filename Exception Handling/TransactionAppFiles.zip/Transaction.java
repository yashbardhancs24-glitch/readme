import java.util.*;

public class Transaction {
    public static void doTrans() throws NegativeAmountException, InsufficientFundsException, NetworkFailureException {
        Random r = new Random();
        int n = r.nextInt(3);
        if(n == 0) throw new NegativeAmountException("neg amt");
        else if(n == 1) throw new InsufficientFundsException("no bal");
        else throw new NetworkFailureException("net bad");
    }

    public static void main(String[] args) {
        boolean ok = false;
        while(!ok) {
            try {
                doTrans();
                System.out.println("done");
                ok = true;
            } catch (NegativeAmountException e) {
                System.out.println("amt prob");
            } catch (InsufficientFundsException e) {
                System.out.println("fund prob");
            } catch (NetworkFailureException e) {
                System.out.println("net prob");
            }
        }
    }
}
