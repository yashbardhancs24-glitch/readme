import java.time.*;

class LateSubmissionException extends Exception {
    public LateSubmissionException(String msg) {
        super(msg);
    }
}

class InvalidFileFormatException extends Exception {
    public InvalidFileFormatException(String msg) {
        super(msg);
    }
}

public class ExamSubmission {
    public static void submitExam(String abc, LocalDateTime xyz) throws LateSubmissionException, InvalidFileFormatException {
        LocalDateTime pqr = LocalDateTime.of(2025, 11, 5, 23, 59);
        if (!abc.endsWith(".pdf")) {
            throw new InvalidFileFormatException("Submission failed: invalid file format");
        }
        if (xyz.isAfter(pqr)) {
            throw new LateSubmissionException("Submission failed: late submission");
        }
        System.out.println("Submission successful");
    }

    public static void main(String[] args) {
        try {
            submitExam("abc.pdf", LocalDateTime.now());
        } catch (LateSubmissionException e) {
            System.out.println(e.getMessage());
        } catch (InvalidFileFormatException e) {
            System.out.println(e.getMessage());
        }
    }
}
