package com.school.util;
import com.school.data.Student;
public class Utility {
    public void displayStudentDetails(Student s) {
        System.out.println(s.toString());
    }
}
