import com.school.data.*;
import com.school.util.*;
public class MainApp {
    public static void main(String[] args) {
        int[] marks = {85, 90, 78, 88, 92};
        Student s = new Student("Yash Bardhan", marks);
        Utility util = new Utility();
        util.displayStudentDetails(s);
    }
}
