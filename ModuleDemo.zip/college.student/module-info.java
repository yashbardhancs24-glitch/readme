module college.student {
    exports college.student;
}
