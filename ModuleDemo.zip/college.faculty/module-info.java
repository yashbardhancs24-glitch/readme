module college.faculty {
    exports college.faculty;
}
