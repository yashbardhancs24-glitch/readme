package college.faculty;
public class Faculty {
    public void displayFaculty(String name, String subject) {
        System.out.println("Faculty Name: " + name);
        System.out.println("Subject: " + subject);
    }
}
