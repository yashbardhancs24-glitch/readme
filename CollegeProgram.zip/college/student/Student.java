package college.student;
public class Student {
    public void displayStudent(String name, int rollNo) {
        System.out.println("Student Name: " + name);
        System.out.println("Roll Number: " + rollNo);
    }
}
